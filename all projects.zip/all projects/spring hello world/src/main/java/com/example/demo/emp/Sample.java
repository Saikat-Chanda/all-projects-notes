package com.example.demo.emp;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class Sample {
	public String hello() {
		return "hello world";
	}
}
