package jdbc;
import java.sql.*;


public class ConnectionDB {

    Connection conn;
    Statement statement;
    String TABLE_NAME = "employee";
    ConnectionDB(String username,String password) {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project",username,password);
            statement = conn.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int insert(int id, String designation, int age, String name, Double salary) throws SQLException {
            String insertStatement = "Insert into " + TABLE_NAME + "(id,name,age,designation,salary) values(" +
                    id + ",'" + name +"'," + age + ",'" + designation + "'," + salary + ");";
            int resultCode = statement.executeUpdate(insertStatement);
            return resultCode;
    }

    public int update(double salary) throws SQLException {
        String insertStatement = "update " + TABLE_NAME + " set salary=" + salary +";";
        System.out.println(insertStatement);
        int resultCode = statement.executeUpdate(insertStatement);
        return resultCode;
    }

    public void display() throws SQLException {
         ResultSet resultSet = statement.executeQuery("select * from employee");
         while (resultSet.next()){
             System.out.println(resultSet.getString("id") + " | " +
                     resultSet.getString("name" ) + " | " +
                     resultSet.getString("designation" ) + " | " +
                     resultSet.getString("salary" ) + " | " +
                     resultSet.getString("age" ));
         }
    }

}
