package com.example.demo.student;

public interface StudentService {
	public StudentModel registerStudent(StudentModel sm);
}
