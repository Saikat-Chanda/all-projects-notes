package com.example.demo.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	StudentRepository repo;

	@Override
	public StudentModel registerStudent(StudentModel studentModel) {
		// TODO Auto-generated method stub
		return repo.save(studentModel);
	}

}
